# TruckSup – Nearby Loads Finder

Website + small Node backend for **transporters to find loads in their nearby city**.

### Running locally

- **Prerequisite**: Node.js installed.
- From `c:\project\trucksup` run:

```bash
npm start
```

This starts the Node server on `http://localhost:3000` and serves both the website and the JSON API.

### How it works

- Use the **City** field and **Radius** dropdown to search.
- Optional filters:
  - **Truck type** (container, flatbed, trailer, mini)
  - **Load type** (industrial, agro, construction, e‑commerce)
  - **Pickup date window**
  - Toggle to **only show verified shippers**.
- Results come from the Node backend:
  - `GET /api/loads` returns all loads (stored in `loads.json` on disk).
  - `POST /api/loads` is used by the **Post a load** form to create new loads which then appear in the board.


