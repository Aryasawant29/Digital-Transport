function getTruckSupUser() {
  try {
    const raw = localStorage.getItem("trucksupUser");
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (err) {
    console.error("Failed to read trucksupUser from storage", err);
    return null;
  }
}

function setTruckSupUser(user) {
  try {
    if (!user) {
      localStorage.removeItem("trucksupUser");
      return;
    }
    localStorage.setItem("trucksupUser", JSON.stringify(user));
  } catch (err) {
    console.error("Failed to write trucksupUser to storage", err);
  }
}

function getTruckSupAccounts() {
  try {
    const raw = localStorage.getItem("trucksupAccounts");
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error("Failed to read trucksupAccounts from storage", err);
    return [];
  }
}

function saveTruckSupAccounts(accounts) {
  try {
    localStorage.setItem("trucksupAccounts", JSON.stringify(accounts));
  } catch (err) {
    console.error("Failed to write trucksupAccounts to storage", err);
  }
}

function findAccountByPhone(phone) {
  const accounts = getTruckSupAccounts();
  return accounts.find((a) => a.phone === phone) || null;
}

function formatUserRole(role) {
  if (role === "shipper") return "Shipper";
  if (role === "transporter") return "Transporter";
  if (role === "both") return "Shipper & transporter";
  return "User";
}

function attachUserChip() {
  const chip = document.getElementById("user-chip");
  if (!chip) return;

  const user = getTruckSupUser();
  if (!user) {
    chip.hidden = true;
    chip.textContent = "";
    return;
  }

  chip.hidden = false;
  const roleLabel = formatUserRole(user.role);
  chip.textContent = `${roleLabel} · ${user.phone}`;
}

document.addEventListener("DOMContentLoaded", attachUserChip);

