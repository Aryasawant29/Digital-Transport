let LOADS = [];

function $(selector) {
  return document.querySelector(selector);
}

function formatPickupTime(isoString) {
  const date = new Date(isoString);
  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();

  const options = {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  };

  const timeStr = date.toLocaleTimeString([], options);
  if (isToday) {
    return `Today · ${timeStr}`;
  }

  const tomorrow = new Date(now);
  tomorrow.setDate(now.getDate() + 1);
  if (date.toDateString() === tomorrow.toDateString()) {
    return `Tomorrow · ${timeStr}`;
  }

  return `${date.toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
  })} · ${timeStr}`;
}

function cityToSlug(city) {
  return city
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, "-")
    .replace(/[^a-z-]/g, "");
}

function distanceLabel(km) {
  if (km < 5) return "Very close";
  if (km < 15) return "Nearby";
  if (km < 40) return "Within city region";
  return "Within driving distance";
}

function matchesDateFilter(pickupTime, filter) {
  if (filter === "any") return true;
  const date = new Date(pickupTime);
  const now = new Date();

  if (filter === "today") {
    return date.toDateString() === now.toDateString();
  }

  if (filter === "tomorrow") {
    const tomorrow = new Date(now);
    tomorrow.setDate(now.getDate() + 1);
    return date.toDateString() === tomorrow.toDateString();
  }

  if (filter === "week") {
    const weekAhead = new Date(now);
    weekAhead.setDate(now.getDate() + 7);
    return date >= now && date <= weekAhead;
  }

  return true;
}

function applyFilters(loads, filters) {
  return loads
    .filter((load) => {
      if (filters.citySlug) {
        const sameCluster =
          load.citySlug === filters.citySlug ||
          cityToSlug(load.fromCity) === filters.citySlug ||
          cityToSlug(load.radiusCity || "") === filters.citySlug;
        if (!sameCluster) {
          return false;
        }
        if (typeof filters.radiusKm === "number" && load.distanceKm > filters.radiusKm) {
          return false;
        }
      }

      if (filters.truckType && load.truckType !== filters.truckType) return false;
      if (filters.loadType && load.loadType !== filters.loadType) return false;
      if (!matchesDateFilter(load.pickupTime, filters.dateFilter)) return false;
      if (filters.onlyVerified && !load.isVerified) return false;

      return true;
    })
    .sort((a, b) => {
      if (filters.sortBy === "distance") {
        return a.distanceKm - b.distanceKm;
      }
      if (filters.sortBy === "price") {
        const priceA = parseInt(a.price.replace(/[^\d]/g, ""), 10);
        const priceB = parseInt(b.price.replace(/[^\d]/g, ""), 10);
        return priceB - priceA;
      }
      const timeA = new Date(a.pickupTime).getTime();
      const timeB = new Date(b.pickupTime).getTime();
      return timeA - timeB;
    });
}

function createLoadCard(load) {
  const card = document.createElement("article");
  card.className = "load-card";

  const badges = [];
  if (load.isVerified) {
    badges.push('<span class="badge badge-verified">Verified</span>');
  }
  if (load.isUrgent) {
    badges.push('<span class="badge badge-urgent">Urgent</span>');
  }

  const weightStr = `${load.weightTonnes}T`;
  const truckLabelMap = {
    container: "Container",
    flatbed: "Flatbed",
    trailer: "Trailer",
    "tata-ace": "Mini",
  };
  const truckLabel = truckLabelMap[load.truckType] || load.truckType;

  const loadTypeLabelMap = {
    industrial: "Industrial",
    agro: "Agro",
    construction: "Construction",
    ecommerce: "E‑commerce",
  };
  const loadTypeLabel = loadTypeLabelMap[load.loadType] || load.loadType;

  card.innerHTML = `
    <div class="load-card-header">
      <div>
        <div class="route-title">${load.fromCity} → ${load.toCity}</div>
        <div class="route-sub">${formatPickupTime(load.pickupTime)}</div>
      </div>
      <div>${badges.join(" ")}</div>
    </div>
    <div class="load-meta">
      <div class="meta-pill">
        <span class="meta-label">${truckLabel}</span>
        <span>${weightStr}</span>
      </div>
      <div class="meta-pill">
        <span class="meta-label">Load</span>
        <span>${loadTypeLabel}</span>
      </div>
      <div class="meta-pill">
        <span class="meta-label">Pickup</span>
        <span>${load.radiusCity || load.fromCity}</span>
      </div>
    </div>
    <div class="load-footer">
      <div>
        <div class="price">${load.price} <span>per ${load.priceUnit}</span></div>
        <div class="shipper-name">${load.shipperName}</div>
      </div>
      <button class="btn-cta" type="button">
        Call now
        <span>›</span>
      </button>
    </div>
    <div class="distance-badge">${load.distanceKm} km · ${distanceLabel(
      load.distanceKm
    )}</div>
  `;

  const ctaButton = card.querySelector(".btn-cta");
  ctaButton.addEventListener("click", () => {
    alert("In a real app, this would show the shipper's contact details and phone number.");
  });

  return card;
}

function renderLoads(filteredLoads, filters) {
  const container = $("#results-container");
  const emptyState = $("#empty-state");
  const cityLabel = $("#results-city-label");
  const loadsMetric = $("#metric-loads-count");

  container.innerHTML = "";

  if (filters.cityName) {
    cityLabel.textContent = filters.cityName;
  } else {
    cityLabel.textContent = "all cities";
  }

  loadsMetric.textContent = filteredLoads.length.toString().padStart(2, "0");

  if (!filteredLoads.length) {
    emptyState.hidden = false;
    return;
  }

  emptyState.hidden = true;

  for (const load of filteredLoads) {
    container.appendChild(createLoadCard(load));
  }
}

function readFiltersFromUI() {
  const cityValue = $("#city-input").value.trim();
  const citySlug = cityValue ? cityToSlug(cityValue) : "";

  return {
    cityName: cityValue || "",
    citySlug: citySlug || "",
    radiusKm: parseInt($("#radius-select").value, 10) || null,
    truckType: $("#truck-type-select").value,
    loadType: $("#load-type-select").value,
    dateFilter: $("#date-select").value,
    onlyVerified: $("#toggle-only-verified").checked,
    sortBy: $("#sort-select").value || "pickup",
  };
}

async function fetchLoads() {
  try {
    const response = await fetch("/api/loads");
    if (!response.ok) {
      throw new Error("Failed to load loads");
    }
    LOADS = await response.json();
  } catch (error) {
    console.error(error);
    LOADS = [];
  }
}

function attachSearchHandlers() {
  const searchButton = $("#btn-search");
  const clearFiltersButton = $("#btn-clear-filters");
  const resetSearchButton = $("#btn-reset-search");

  if (!searchButton || !clearFiltersButton || !resetSearchButton) {
    console.error("Search controls not found in the page.");
    const fallbackFilters = {
      cityName: "",
      citySlug: "",
      radiusKm: null,
      truckType: "",
      loadType: "",
      dateFilter: "any",
      onlyVerified: true,
      sortBy: "pickup",
    };
    renderLoads(LOADS, fallbackFilters);
    return;
  }

  const inputsThatTriggerSearch = [
    "#radius-select",
    "#truck-type-select",
    "#load-type-select",
    "#date-select",
    "#toggle-only-verified",
    "#sort-select",
  ];

  function runSearch() {
    const filters = readFiltersFromUI();
    const filtered = applyFilters(LOADS, filters);
    renderLoads(filtered, filters);
  }

  searchButton.addEventListener("click", (event) => {
    event.preventDefault();
    runSearch();
  });

  const cityInput = $("#city-input");
  if (cityInput) {
    cityInput.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        runSearch();
      }
    });
  }

  for (const selector of inputsThatTriggerSearch) {
    const el = document.querySelector(selector);
    if (el) {
      el.addEventListener("change", runSearch);
    }
  }

  clearFiltersButton.addEventListener("click", () => {
    $("#truck-type-select").value = "";
    $("#load-type-select").value = "";
    $("#date-select").value = "any";
    $("#toggle-only-verified").checked = true;
    $("#sort-select").value = "pickup";
    runSearch();
  });

  resetSearchButton.addEventListener("click", () => {
    $("#city-input").value = "";
    $("#radius-select").value = "25";
    $("#truck-type-select").value = "";
    $("#load-type-select").value = "";
    $("#date-select").value = "any";
    $("#toggle-only-verified").checked = true;
    $("#sort-select").value = "pickup";
    const filters = readFiltersFromUI();
    renderLoads(LOADS, filters);
  });

  const initialFilters = readFiltersFromUI();
  renderLoads(LOADS, initialFilters);
}

function attachModalHandlers() {
  const backdrop = $("#modal-backdrop");
  const openButton = $("#btn-post-load");
  const closeButton = $("#modal-close");
  const cancelButton = $("#btn-cancel-modal");
  const form = $("#post-load-form");

  function openModal() {
    backdrop.hidden = false;
    backdrop.style.display = "flex";
  }

  function closeModal() {
    backdrop.hidden = true;
    backdrop.style.display = "none";
  }

  openButton.addEventListener("click", openModal);
  closeButton.addEventListener("click", closeModal);
  cancelButton.addEventListener("click", closeModal);

  backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) {
      closeModal();
    }
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const payload = {
      fromCity: document.querySelector("#from-city-input").value,
      toCity: document.querySelector("#to-city-input").value,
      truckType: document.querySelector("#truck-type-modal-select").value,
      weightTonnes: Number(document.querySelector("#load-weight-input").value || 0)
    };

    try {
      const response = await fetch("/api/loads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error("Failed to post load");
      }

      const created = await response.json();
      LOADS.push(created);

      const filters = readFiltersFromUI();
      const filtered = applyFilters(LOADS, filters);
      renderLoads(filtered, filters);

      closeModal();
      alert("Load submitted and added to the board.");
      form.reset();
    } catch (error) {
      console.error(error);
      alert("There was a problem submitting your load. Please try again.");
    }
  });
}

function attachHowItWorks() {
  const button = $("#btn-how-it-works");
  button.addEventListener("click", () => {
    alert(
      [
        "TruckSup connects verified shippers with nearby transporters.",
        "",
        "1. Shippers post loads with origin, destination, truck type and pricing.",
        "2. Transporters search by their city and filters like truck type.",
        "3. Once interested, they call the shipper and confirm the trip.",
      ].join("\n")
    );
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  await fetchLoads();
  attachSearchHandlers();
  attachModalHandlers();
  attachHowItWorks();
});

