const fs = require('fs');
const express = require('express');
const path = require('path');
const session = require('express-session');

const app = express();
app.use(express.urlencoded({ extended: true }));

// View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static Files
app.use(express.static(path.join(__dirname, 'public')));

// Session
app.use(session({
    secret: 'trucksecret',
    resave: false,
    saveUninitialized: true
}));

const usersFile = './data/users.json';
const loadsFile = './data/loads.json';


// ================= HOME =================
app.get('/', (req, res) => {
    res.render('home');
});


// ================= LOGIN PAGES =================
app.get('/login-admin', (req, res) => res.render('login-admin'));
app.get('/login-shipper', (req, res) => res.render('login-shipper'));
app.get('/login-transporter', (req, res) => res.render('login-transporter'));


// ================= SIMPLE LOGIN =================

// ADMIN LOGIN
app.post('/admin-login', (req,res)=>{
    req.session.user = {
        username: req.body.username,
        role: "admin"
    };
    res.redirect('/admin-dashboard');
});

// SHIPPER LOGIN
app.post('/shipper-login', (req,res)=>{
    req.session.user = {
        username: req.body.username,
        role: "shipper"
    };
    res.redirect('/shipper-dashboard');
});

// TRANSPORTER LOGIN
app.post('/transporter-login', (req,res)=>{
    req.session.user = {
        username: req.body.username,
        role: "transporter"
    };
    res.redirect('/transporter-dashboard');
});


// ================= DASHBOARD PROTECTION =================
function checkLogin(req,res,next){
    if(!req.session.user){
        return res.redirect('/');
    }
    next();
}


// ================= SHIPPER DASHBOARD =================
app.get('/shipper-dashboard', checkLogin, (req, res) => {

    let loads = JSON.parse(fs.readFileSync(loadsFile));

    let total = loads.length;
    let pending = loads.filter(l => !l.status || l.status === "Pending").length;
    let accepted = loads.filter(l => l.status === "Accepted").length;
    let delivered = loads.filter(l => l.status === "Delivered").length;

    res.render('shipper-dashboard', { loads, total, pending, accepted, delivered });
});


// ================= TRANSPORTER DASHBOARD =================
app.get('/transporter-dashboard', checkLogin, (req, res) => {
    let loads = JSON.parse(fs.readFileSync(loadsFile));
    res.render('transporter-dashboard', { loads });
});


// ================= ADMIN DASHBOARD =================
app.get('/admin-dashboard', checkLogin, (req,res)=>{

    let loads = JSON.parse(fs.readFileSync(loadsFile));

    let total = loads.length;
    let pending = loads.filter(l => !l.status || l.status === "Pending").length;
    let accepted = loads.filter(l => l.status === "Accepted").length;
    let delivered = loads.filter(l => l.status === "Delivered").length;

    res.render('admin-dashboard', {
        loads,
        total,
        pending,
        accepted,
        delivered,
        search: ""
    });
});


// ================= POST LOAD =================
app.post('/post-load', checkLogin, (req,res)=>{

    let loads = JSON.parse(fs.readFileSync(loadsFile));

    loads.push({
        pickup: req.body.pickup,
        drop: req.body.drop,
        weight: req.body.weight,
        truck: req.body.truck,
        price: req.body.price,
        date: req.body.date,
        status: "Pending"
    });

    fs.writeFileSync(loadsFile, JSON.stringify(loads,null,2));

    res.redirect('/shipper-dashboard');
});


// ================= ACCEPT LOAD =================
app.post('/accept-load', checkLogin, (req,res)=>{

    let loads = JSON.parse(fs.readFileSync(loadsFile));
    const id = parseInt(req.body.id);

    if(!isNaN(id)){
        loads[id].status = "Accepted";
        fs.writeFileSync(loadsFile, JSON.stringify(loads,null,2));
    }

    res.redirect('/transporter-dashboard');
});


// ================= DELIVER LOAD =================
app.post('/deliver-load', checkLogin, (req,res)=>{

    let loads = JSON.parse(fs.readFileSync(loadsFile));
    const id = parseInt(req.body.id);

    if(!isNaN(id)){
        loads[id].status = "Delivered";
        fs.writeFileSync(loadsFile, JSON.stringify(loads,null,2));
    }

    res.redirect('/transporter-dashboard');
});


// ================= DELETE LOAD =================
app.post('/delete-load', checkLogin, (req,res)=>{

    let loads = JSON.parse(fs.readFileSync(loadsFile));
    const id = parseInt(req.body.id);

    if(!isNaN(id)){
        loads.splice(id, 1);
        fs.writeFileSync(loadsFile, JSON.stringify(loads,null,2));
    }

    res.redirect('/admin-dashboard');
});


// ================= LOGOUT =================
app.get('/logout', (req,res)=>{
    req.session.destroy(()=>{
        res.redirect('/');
    });
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});